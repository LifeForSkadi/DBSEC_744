package entity;

public class student {
    public Integer student_id;
    public String name;
    public Integer age;
    public Integer class_id;

    public student() {
    }
    public student( Integer id,String name, Integer age, Integer class_id) {
        this.student_id = id;
        this.name = name;
        this.age = age;
        this.class_id = class_id;
    }
    public student( String name, Integer age, Integer class_id) {
        this.name = name;
        this.age = age;
        this.class_id = class_id;
    }
    public Integer getStudent_id() {
        return student_id;
    }
    public void setStudent_id(Integer student_id) {
        this.student_id = student_id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getAge() {
        return age;
    }
    public void setAge(Integer age) {
        this.age = age;
    }
    public Integer getClass_id() {
        return class_id;
    }
    public void setClass_id(Integer class_id) {
        this.class_id = class_id;
    }



}
