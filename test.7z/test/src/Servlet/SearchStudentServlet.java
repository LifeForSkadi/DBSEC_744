package Servlet;

import Dao.studentDao;
import entity.student;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/selectById")
public class SearchStudentServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        int id = Integer.valueOf(request.getParameter("student_id"));

        studentDao ud = new studentDao();
        student user = ud.selectById(id);
        request.setAttribute("user_attribute", user);
        request.getRequestDispatcher("studentUpdate.jsp").forward(request,response);
    }
}
