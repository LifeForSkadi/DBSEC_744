package entity;

public class teacher {
    public Integer teacher_id;
    public String name;
    public String title;
    public String department;

    public teacher() {
    }
    public teacher(Integer id, String name,String title,String department) {
        this.teacher_id = id;
        this.name = name;
        this.title = title;
        this.department = department;
    }
    public teacher(String name, String title,String department) {
        this.name = name;
        this.title = title;
        this.department = department;
    }
    public Integer getTeacher_id() {
        return teacher_id;
    }
    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getDepartment() {
        return department;
    }
    public void setDepartment(String department) {
        this.department = department;
    }



}
