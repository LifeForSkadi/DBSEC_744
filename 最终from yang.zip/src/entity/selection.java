package entity;

public class selection {
    public Integer selection_id;
    public Integer student_id;
    public Integer course_id;


    public selection() {
    }
    public selection(Integer selection_id, Integer student_id, Integer course_id) {
        this.selection_id = selection_id;
        this.student_id =student_id ;
        this.course_id = course_id;
    }
    public selection(Integer student_id, Integer course_id ) {
        this.student_id = student_id;
        this.course_id = course_id;

    }
    public Integer getSelection_id() {
        return selection_id;
    }
    public void setSelection_id(Integer selection_id) {
        this.selection_id = selection_id;
    }
    public Integer getStudent_id() {
        return student_id;
    }
    public void setStudent_id(Integer student_id) {
        this.student_id = student_id;
    }
    public Integer getCourse_id() {
        return course_id;
    }
    public void setCourse_id(Integer course_id) {
        this.course_id = course_id;
    }




}
