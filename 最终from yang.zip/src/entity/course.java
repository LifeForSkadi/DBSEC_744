package entity;

public class course {
    public Integer course_id;
    public String course_name;
    public String description;


    public course() {
    }
    public course(Integer course_id, String course_name, String description) {
        this.course_id = course_id;
        this.course_name = course_name;
        this.description = description;
    }
    public course(String course_name, String description ) {
        this.course_name = course_name;
        this.description = description;

    }
    public Integer getCourse_id() {
        return course_id;
    }
    public void setCourse_id(Integer course_id) {
        this.course_id = course_id;
    }
    public String getCourse_name() {
        return course_name;
    }
    public void setCourse_name(String course_name) {
        this.course_name = course_name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }




}
