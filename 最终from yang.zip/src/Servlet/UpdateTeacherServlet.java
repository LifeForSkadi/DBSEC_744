package Servlet;

import Dao.teacherDao;
import entity.teacher;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/Tupdate")
public class UpdateTeacherServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        int teacher_id = Integer.valueOf(request.getParameter("teacher_id"));
        String name = request.getParameter("name");
        String title = request.getParameter("title");
        String department = request.getParameter("department");

        teacher user = new teacher();
        user.setTeacher_id(teacher_id);
        user.setName(name);
        user.setTitle(title);
        user.setDepartment(department);

        teacherDao ud = new teacherDao();
        //调用修改接口
        int count = ud.update(user);
        String str=null;
        if(count>0){
            str="修改用户信息成功";
        }else{
            str="修改用户信息失败";
        }

        PrintWriter out = response.getWriter();
        out.print("<script>");
        out.print("alert('" +str+ "');");
        out.print("location.href='TselectAll'");
        out.print("</script>");
        out.close();

    }
}
