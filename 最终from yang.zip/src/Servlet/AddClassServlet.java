package Servlet;

import Dao.classDao;
import entity.classes;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/cinsert")
public class AddClassServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        String class_id = request.getParameter("class_id");
        String class_name = request.getParameter("class_name");
        String teacher_id = request.getParameter("teacher_id");



        classes user = new classes();
        user.setClass_id(Integer.valueOf(class_id));
        user.setClass_name(class_name);
        user.setTeacher_id(Integer.valueOf(teacher_id));

        //快捷键是ctrl+alt+v
        classDao ud = new classDao();
        //调用添加接口
        int count = ud.insert(user);
        String str=null;
        if(count>0){
            str="添加新班级信息成功";
        }else{
            str="添加新班级信息失败";
        }

        PrintWriter out = response.getWriter();
        out.print("<script>");
        out.print("alert('" +str+ "');");//漏了一个分号
        out.print("location.href='cselectAll'");
        out.print("</script>");
        out.close();
    }
}
