package Servlet;

import Dao.teacherDao;
import entity.teacher;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/Tinsert")
public class AddTeacherServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        String teacher_id = request.getParameter("teacher_id");
        String name = request.getParameter("name");
        String title = request.getParameter("title");
        String department = request.getParameter("department");



        teacher user = new teacher();
        user.setTeacher_id(Integer.valueOf(teacher_id));
        user.setName(name);
        user.setTitle(title);
        user.setDepartment(department);

        //快捷键是ctrl+alt+v
        teacherDao ud = new teacherDao();
        //调用添加接口
        int count = ud.insert(user);
        String str=null;
        if(count>0){
            str="添加新用户信息成功";
        }else{
            str="添加新用户信息失败";
        }

        PrintWriter out = response.getWriter();
        out.print("<script>");
        out.print("alert('" +str+ "');");//漏了一个分号
        out.print("location.href='TselectAll'");
        out.print("</script>");
        out.close();
    }
}
