package Servlet;

import Dao.courseDao;
import entity.course;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/Cupdate")
public class UpdateCourseServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        int course_id = Integer.parseInt(request.getParameter("course_id"));
        String course_name = request.getParameter("course_name");
        String description = request.getParameter("description");

        course user = new course();
        user.setCourse_id(course_id);
        user.setCourse_name(course_name);
        user.setDescription(description);

        courseDao ud = new courseDao();
        //调用修改接口
        int count = ud.update(user);
        String str=null;
        if(count>0){
            str="修改课程信息成功";
        }else{
            str="修改课程信息失败";
        }

        PrintWriter out = response.getWriter();
        out.print("<script>");
        out.print("alert('" +str+ "');");
        out.print("location.href='CselectAll'");
        out.print("</script>");
        out.close();

    }
}
