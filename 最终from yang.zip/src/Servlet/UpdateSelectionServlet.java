package Servlet;

import Dao.selectionDao;
import entity.selection;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/csupdate")
public class UpdateSelectionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        int selection_id = Integer.parseInt(request.getParameter("selection_id"));
        int student_id = Integer.parseInt(request.getParameter("student_id"));
        int course_id = Integer.parseInt(request.getParameter("course_id"));

        selection user = new selection();
        user.setSelection_id(selection_id);
        user.setStudent_id(student_id);
        user.setCourse_id(course_id);

        selectionDao ud = new selectionDao();
        //调用修改接口
        int count = ud.update(user);
        String str=null;
        if(count>0){
            str="修改选课信息成功";
        }else{
            str="修改选课信息失败";
        }

        PrintWriter out = response.getWriter();
        out.print("<script>");
        out.print("alert('" +str+ "');");
        out.print("location.href='csselectAll'");
        out.print("</script>");
        out.close();

    }
}
