package Servlet;

import Dao.teacherDao;
import entity.teacher;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;


@WebServlet("/TselectById")
public class SearchTeacherServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        int id = Integer.parseInt(request.getParameter("teacher_id"));

        teacherDao ud = new teacherDao();
        teacher user = ud.selectById(id);
        request.setAttribute("user_attribute", user);
        request.getRequestDispatcher("teacherUpdate.jsp").forward(request,response);
    }
}
