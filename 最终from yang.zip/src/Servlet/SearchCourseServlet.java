package Servlet;

import Dao.courseDao;
import entity.course;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/CselectById")
public class SearchCourseServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        int id = Integer.parseInt(request.getParameter("course_id"));

        courseDao ud = new courseDao();
        course user = ud.selectById(id);
        request.setAttribute("user_attribute", user);
        request.getRequestDispatcher("courseUpdate.jsp").forward(request,response);
    }
}
