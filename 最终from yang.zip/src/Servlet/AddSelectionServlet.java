package Servlet;

import Dao.selectionDao;
import entity.selection;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/csinsert")
public class AddSelectionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        String selection_id = request.getParameter("selection_id");
        String student_id = request.getParameter("student_id");
        String course_id = request.getParameter("course_id");



        selection user = new selection();
        user.setSelection_id(Integer.valueOf(selection_id));
        user.setStudent_id(Integer.valueOf(student_id));
        user.setCourse_id(Integer.valueOf(course_id));

        //快捷键是ctrl+alt+v
        selectionDao ud = new selectionDao();
        //调用添加接口
        int count = ud.insert(user);
        String str=null;
        if(count>0){
            str="添加新选课信息成功";
        }else{
            str="添加新选课信息失败";
        }

        PrintWriter out = response.getWriter();
        out.print("<script>");
        out.print("alert('" +str+ "');");//漏了一个分号
        out.print("location.href='csselectAll'");
        out.print("</script>");
        out.close();
    }
}
