package Servlet;

import Dao.classDao;
import entity.classes;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/cupdate")
public class UpdateClassServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        int class_id = Integer.parseInt(request.getParameter("class_id"));
        String class_name = request.getParameter("class_name");
        int teacher_id = Integer.parseInt(request.getParameter("teacher_id"));

        classes user = new classes();
        user.setClass_id(class_id);
        user.setClass_name(class_name);
        user.setTeacher_id(teacher_id);

        classDao ud = new classDao();
        //调用修改接口
        int count = ud.update(user);
        String str=null;
        if(count>0){
            str="修改班级信息成功";
        }else{
            str="修改班级信息失败";
        }

        PrintWriter out = response.getWriter();
        out.print("<script>");
        out.print("alert('" +str+ "');");
        out.print("location.href='cselectAll'");
        out.print("</script>");
        out.close();

    }
}
