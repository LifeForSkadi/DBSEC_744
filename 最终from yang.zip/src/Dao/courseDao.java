package Dao;
import entity.course;
import util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class courseDao {

    public List<course> selectAll(){
        List<course> list = new ArrayList<>();
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("select * from courses;");
            rs = pstmt.executeQuery();
            if(rs!=null){
                System.out.println("连接成功");
            }
            // 使用rs.next()方法一行一行读取查询结果
            while(rs.next()){
                course u = new course(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3) );
                list.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    public int insert(course u){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            // 问号？是占位符
            pstmt = conn.prepareStatement("insert into courses(course_id,course_name,description) values (?,?, ?);");
            // 传递参数
            pstmt.setInt(1, u.getCourse_id());
            pstmt.setString(2, u.getCourse_name());
            pstmt.setString(3, u.getDescription());
            // 执行insert操作，并获取被更新的行数
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }
    public  course selectById(int course_id){
        course u = new course();
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("select * from courses where course_id = ?");
            pstmt.setInt(1, course_id); // 将占位符 ？的值设置为 id
            rs = pstmt.executeQuery();
            while (rs.next()){
                u = new course(rs.getInt(1), // 从结果集获取第一列的整数值
                        rs.getString(2), // 从结果集获取第二列的字符串值，后面以此类推
                        rs.getString(3));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return u;}
    public int update(course u){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("update courses set course_name = ?, description = ? where course_id = ?");
            pstmt.setString(1, u.getCourse_name());
            pstmt.setString(2, u.getDescription());
            pstmt.setInt(3, u.getCourse_id());
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }
    public int delete(int course_id){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("delete from courses where course_id = ?");
            pstmt.setInt(1, course_id);
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }



}
