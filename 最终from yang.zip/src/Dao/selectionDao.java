package Dao;
import entity.selection;
import util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class selectionDao {

    public List<selection> selectAll(){
        List<selection> list = new ArrayList<>();
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("select * from course_selections;");
            rs = pstmt.executeQuery();
            if(rs!=null){
                System.out.println("连接成功");
            }
            // 使用rs.next()方法一行一行读取查询结果
            while(rs.next()){
                selection u = new selection(rs.getInt(1),
                        rs.getInt(2),
                        rs.getInt(3) );
                list.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    public int insert(selection u){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            // 问号？是占位符
            pstmt = conn.prepareStatement("insert into course_selections(selection_id,student_id,course_id) values (?,?, ?);");
            // 传递参数
            pstmt.setInt(1, u.getSelection_id());
            pstmt.setInt(2, u.getStudent_id());
            pstmt.setInt(3, u.getCourse_id());
            // 执行insert操作，并获取被更新的行数
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }
    public  selection selectById(int selection_id){
        selection u = new selection();
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("select * from course_selections where selection_id = ?");
            pstmt.setInt(1, selection_id); // 将占位符 ？的值设置为 id
            rs = pstmt.executeQuery();
            while (rs.next()){
                u = new selection(rs.getInt(1), // 从结果集获取第一列的整数值
                        rs.getInt(2), // 从结果集获取第二列的字符串值，后面以此类推
                        rs.getInt(3));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return u;}
    public int update(selection u){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("update course_selections set student_id = ?, course_id = ? where selection_id = ?");
            pstmt.setInt(1, u.getStudent_id());
            pstmt.setInt(2, u.getCourse_id());
            pstmt.setInt(3, u.getSelection_id());
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }
    public int delete(int selection_id){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("delete from course_selections where selection_id = ?");
            pstmt.setInt(1, selection_id);
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }



}
