package Dao;
import entity.student;
import util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class studentDao {

    public List<student> selectAll(){
        List<student> list = new ArrayList<>();
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("select * from students;");
            rs = pstmt.executeQuery();
            if(rs!=null){
                System.out.println("连接成功");
            }
            // 使用rs.next()方法一行一行读取查询结果
            while(rs.next()){
                student u = new student(rs.getInt(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getInt(4));
                list.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    public int insert(student u){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            // 问号？是占位符
            pstmt = conn.prepareStatement("insert into students(student_id,name,age,class_id) values (?,?, ?, ?);");
            // 传递参数
            pstmt.setInt(1, u.getStudent_id());
            pstmt.setString(2, u.getName());
            pstmt.setInt(3, u.getAge());
            pstmt.setInt(4, u.getClass_id());
            // 执行insert操作，并获取被更新的行数
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }
    public  student selectById(int student_id){
        student u = new student();
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("select * from students where student_id = ?");
            pstmt.setInt(1, student_id); // 将占位符 ？的值设置为 id
            rs = pstmt.executeQuery();
            while (rs.next()){
                u = new student(rs.getInt(1), // 从结果集获取第一列的整数值
                        rs.getString(2), // 从结果集获取第二列的字符串值，后面以此类推
                        rs.getInt(3),
                        rs.getInt(4));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return u;}
    public int update(student u){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("update students set name = ?, age = ?, class_id = ? where student_id = ?");
            pstmt.setString(1, u.getName());
            pstmt.setInt(2, u.getAge());
            pstmt.setInt(3, u.getClass_id());
            pstmt.setInt(4, u.getStudent_id());
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }
    public int delete(int student_id){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("delete from students where student_id = ?");
            pstmt.setInt(1, student_id);
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }



}
