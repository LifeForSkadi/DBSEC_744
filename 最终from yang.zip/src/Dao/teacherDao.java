package Dao;
import entity.teacher;
import util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class teacherDao {

    public List<teacher> selectAll(){
        List<teacher> list = new ArrayList<>();
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("select * from teachers;");
            rs = pstmt.executeQuery();
            if(rs!=null){
                System.out.println("连接成功");
            }
            // 使用rs.next()方法一行一行读取查询结果
            while(rs.next()){
                teacher u = new teacher(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4));
                list.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    public int insert(teacher u){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            // 问号？是占位符
            pstmt = conn.prepareStatement("insert into teachers(teacher_id,name,title,department) values (?,?, ?, ?);");
            // 传递参数
            pstmt.setInt(1, u.getTeacher_id());
            pstmt.setString(2, u.getName());
            pstmt.setString(3, u.getTitle());
            pstmt.setString(4, u.getDepartment());
            // 执行insert操作，并获取被更新的行数
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }
    public  teacher selectById(int teacher_id){
        teacher u = new teacher();
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("select * from teachers where teacher_id = ?");
            pstmt.setInt(1, teacher_id); // 将占位符 ？的值设置为 id
            rs = pstmt.executeQuery();
            while (rs.next()){
                u = new teacher(rs.getInt(1), // 从结果集获取第一列的整数值
                        rs.getString(2), // 从结果集获取第二列的字符串值，后面以此类推
                        rs.getString(3),
                        rs.getString(4));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return u;}
    public int update(teacher u){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("update teachers set name = ?, title = ?, department = ? where teacher_id = ?");
            pstmt.setString(1, u.getName());
            pstmt.setString(2, u.getTitle());
            pstmt.setString(3, u.getDepartment());
            pstmt.setInt(4, u.getTeacher_id());
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }
    public int delete(int teacher_id){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("delete from teachers where teacher_id = ?");
            pstmt.setInt(1, teacher_id);
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }



}
