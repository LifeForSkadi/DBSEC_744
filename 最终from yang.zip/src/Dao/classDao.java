package Dao;
import entity.classes;
import util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class classDao {

    public List<classes> selectAll(){
        List<classes> list = new ArrayList<>();
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("select * from classes;");
            rs = pstmt.executeQuery();
            if(rs!=null){
                System.out.println("连接成功");
            }
            // 使用rs.next()方法一行一行读取查询结果
            while(rs.next()){
                classes u = new classes(rs.getInt(1),
                        rs.getString(2),
                        rs.getInt(3) );
                list.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    public int insert(classes u){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            // 问号？是占位符
            pstmt = conn.prepareStatement("insert into classes(class_id,class_name,teacher_id) values (?,?, ?);");
            // 传递参数
            pstmt.setInt(1, u.getClass_id());
            pstmt.setString(2, u.getClass_name());
            pstmt.setInt(3, u.getTeacher_id());
            // 执行insert操作，并获取被更新的行数
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }
    public  classes selectById(int class_id){
        classes u = new classes();
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("select * from classes where class_id = ?");
            pstmt.setInt(1, class_id); // 将占位符 ？的值设置为 id
            rs = pstmt.executeQuery();
            while (rs.next()){
                u = new classes(rs.getInt(1), // 从结果集获取第一列的整数值
                        rs.getString(2), // 从结果集获取第二列的字符串值，后面以此类推
                        rs.getInt(3));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return u;}
    public int update(classes u){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("update classes set class_name = ?, teacher_id = ? where class_id = ?");
            pstmt.setString(1, u.getClass_name());
            pstmt.setInt(2, u.getTeacher_id());
            pstmt.setInt(3, u.getClass_id());
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }
    public int delete(int class_id){
        int count = 0;
        Connection conn = DBConnectionUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            pstmt = conn.prepareStatement("delete from classes where class_id = ?");
            pstmt.setInt(1, class_id);
            count = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBConnectionUtil.closeConnection(conn, pstmt, rs);
        }
        return count;
    }



}
